/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.latihan_9_prog2;
import java.util.Scanner; //sebuah clas yg di gunakan untuk input

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author el
 */
public class nilaimhs {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String nim, nama, grade;
        double uts, uas,NIH,NIA, rata;
        
        System.out.println("Data: ");
        System.out.print("NIM: "); nim = input.next();
        System.out.print("Nama: "); nama = input.next();
        System.out.print("Nilai UTS: "); uts = input.nextDouble();
        System.out.print("Nilai UAS: "); uas = input.nextDouble();
        System.out.print("Nilai NIH: "); NIH = input.nextDouble();
        System.out.print("Nilai NIA: "); NIA = input.nextDouble();
        rata = (uts + uas + NIH + NIA ) / 4;
        
        if (rata < 50)
            grade = "E";
        else if (rata <60)
            grade = "D";
        else if (rata <70)
            grade = "C";
        else if (rata <80)
            grade = "B";
        else
            grade = "A";
        
        System.out.println("==============================================");
        System.out.println("NIM\tNama\t\tUTS\tUAS\\tNIH\tNIA\tRata2\tGrade");
        System.out.println("==============================================");
        System.out.println(nim+"\t"+nama+"\t"+uts+"\t"+uas+"\t"+NIH+"\t" +NIA+"\t"+rata+"\t"+grade);//fungsi /t buat spasi/jarak
        System.out.println("");
        System.out.println("");
        
    }
}

